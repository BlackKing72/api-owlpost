var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var api_exports = {};
__export(api_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(api_exports);
const expressFileUpload = require("express-fileupload");
const serverless = require("serverless-http");
const express = require("express");
const cors = require("cors");
const owlpostRouter = require("./routes/owlpostRouter");
const api = express();
const port = 3e3;
api.use(cors({
  origin: "*",
  methods: ["POST", "PUT", "PATCH", "DELETE", "GET"],
  allowedHeaders: ["Content-Type", "Authorization"],
  credentials: true
}));
api.use(express.json({
  limits: "40mb"
}));
api.use(expressFileUpload({
  limits: {
    fileSize: 40 * 1024 * 1024
    // Limite de 40MB
  }
}));
api.use("/", owlpostRouter);
api.get("/", (req, res) => res.send("Express on Vercel"));
const handler = serverless(api);
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
